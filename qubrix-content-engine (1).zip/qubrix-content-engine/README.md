# Qubrix Content Engine - Phase 1 (foundation)

Multi-tenant SaaS foundation: Next.js (App Router) + TypeScript + Tailwind + Supabase Auth/Postgres with Row Level Security.
Phase 1 = sign up / log in, organizations (creator, business, agency), brands, projects, secured database, Super Admin check,
and an automated tenant-isolation test suite. Video, AI and dashboards come in later phases. See `docs/`.
The old Express prototype is kept in `archive/phase0-express-prototype/` for reference only.

## What you need first (one-time)
1. **Node.js 20.9 or newer** (LTS is fine) - https://nodejs.org - check with `node -v`
2. **Docker Desktop** (runs the local database) - https://www.docker.com/products/docker-desktop - open it and wait until it says it is running. (Windows: choose the WSL 2 option when asked.)

## Run it locally
Open a terminal **inside the project folder**, then:

1. Install packages: `npm install`
2. Start the local database (first time downloads a few GB and takes several minutes): `npm run db:start`
   When it finishes it prints addresses and keys. Keep that window's output handy; show it again anytime with `npm run db:status`.
3. Create your settings file:
   - Mac/Linux: `cp .env.example .env.local`
   - Windows PowerShell: `copy .env.example .env.local`
4. Open `.env.local` in an editor. Set `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=` to the **Publishable** key from step 2
   (older CLI versions call it the **anon key**). Leave the other two lines as they are. Do NOT use the "secret"/"service_role" key.
5. Start the app: `npm run dev` and open http://localhost:3000
6. Click **Create account**, use a password of 12+ characters. Confirmation emails never leave your computer: open
   **http://127.0.0.1:54324** (Inbucket), open the email and click the confirm link. Then log in.
7. Create your workspace on the onboarding page. Try Brands and Projects. (Pick "Agency" to add several brands.)

## Run the security tests (the Phase 1 gate)
With the database running: `npm run db:reset` then `npm test`. You should see `28 passed`.
These tests act as different users and prove one tenant can never see or change another tenant's data.
(No Docker? They also run on any plain PostgreSQL: load `tests/rls/stub-auth.sql` then every file in `supabase/migrations/`, and set `TEST_DATABASE_URL`.)

## Become a Super Admin (optional)
Super Admins cannot be created from the app on purpose. Open Supabase Studio at http://127.0.0.1:54323 > SQL Editor and run
(with your own email):
```sql
insert into public.platform_admins (user_id) select id from auth.users where email = 'you@example.com';
```
Then visit http://localhost:3000/admin. Everyone else sees "Page not found".

## Everyday commands
| Command | What it does |
|---|---|
| `npm run dev` | start the app |
| `npm run db:start` / `db:stop` | start / stop the local database |
| `npm run db:reset` | wipe the local database and re-apply all migrations |
| `npm run typecheck` | check the TypeScript |
| `npm test` | tenant-isolation tests |

## Troubleshooting
- **"Invalid or missing environment variables"** - `.env.local` is missing or the key is empty/partial.
- **`db:start` fails** - Docker Desktop is not running yet.
- **Port already in use** - close the other program, or run `npm run dev -- -p 3001` (then also change `NEXT_PUBLIC_SITE_URL` and `site_url` in `supabase/config.toml`).
- **No confirmation email** - look in http://127.0.0.1:54324, not your real inbox.
- **Changed `.env.local` but nothing happened** - stop (`Ctrl+C`) and restart `npm run dev`.

## Going live later (not part of Phase 1)
Create a hosted Supabase project, run the migrations (`supabase link` then `supabase db push`), set the three `NEXT_PUBLIC_*` variables in Vercel,
and set the Site URL and redirect URLs in Supabase Auth settings.
