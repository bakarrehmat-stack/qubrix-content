# Security rules for contributors

1. **RLS is the real lock.** Every new table: enable RLS, revoke default grants, grant only what is needed, add policies, add tests in `tests/rls/`.
2. **Never trust the browser.** Organization ids come from the verified membership (`requireOrgAccess`), never from form fields.
3. **Check permissions in the server, every time.** `proxy.ts` is only for session refresh and redirects. Pages and Server Actions call `requireUser` / `requireOrgAccess` themselves.
4. **No secret key in Phase 1.** If a service-role/secret key is ever introduced it lives only in server-only code, never in `NEXT_PUBLIC_*`, and every use writes an audit row.
5. **Super Admin does not bypass RLS.** The admin table is unreadable through the API; admin power is added later as narrow, audited server operations.
6. **Generic auth errors.** Login and password reset never reveal whether an email exists.
7. **Validate everything with zod** before it touches the database.
8. Run `npm test` against a freshly reset database before every merge. A failing isolation test blocks release.
