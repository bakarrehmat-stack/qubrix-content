# Architecture (Phase 1)

Next.js (App Router, TypeScript, Tailwind) on Vercel -> Supabase (Auth + Postgres + RLS).

## Tenancy model
organization (creator | business | agency) -> brands -> projects. Users join organizations through `memberships`
(owner | admin | editor | viewer). One user may belong to many organizations.
Every creator/business organization gets one hidden default brand, so every project always has a brand.
Only agencies may add more brands (enforced by a database trigger).

## Future agency subclients (NOT built yet)
All brand/project policies call `private.can_access_brand(brand_id)`. To add client logins later:
create `brand_members (brand_id, user_id, role)`, extend ONLY that function to also accept brand members,
and add a `/portal` route group. No existing policy or table needs rebuilding.

## Usage ledger (billing is out of scope)
`usage_events` stores raw, append-only events. Allowed `event_type` values:
`video_uploaded`, `video_minutes_transcribed`, `ai_tokens_used`, `render_seconds`, `clip_downloaded`.
Plans, limits and invoices will later be queries over this table. API roles cannot write to it; only trusted server code will.

## Storage path convention (for the upload phase)
`{organization_id}/{brand_id}/{project_id}/{asset_id}/{filename}` - storage policies will reuse the same membership check.

## Reserved
`brands.settings` (jsonb) is reserved for the future brand kit (logo, colors, fonts, caption style).

## Roadmap
1 Foundation (this) - 2 Dashboards, client management, invitations - 3 Video upload - 4 Queue, worker, transcription -
5 AI moment detection + clip selection - 6 Vertical render, captions, branding - 7 Hooks/titles/hashtags + MP4 download -
8 Hardening (nonce CSP, rate limits, monitoring, backups). Worker host: provisional Google Cloud Run Jobs; decide after a benchmark.
