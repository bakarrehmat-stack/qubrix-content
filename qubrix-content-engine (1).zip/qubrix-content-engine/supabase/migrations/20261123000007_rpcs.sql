-- 0007: create an organization + owner membership + default brand atomically.
create or replace function public.create_organization(p_name text, p_slug text, p_type public.org_type)
returns uuid language plpgsql security definer set search_path = '' as $$
declare uid uuid := (select auth.uid()); org uuid; owned int;
begin
  if uid is null then raise exception 'Not authenticated' using errcode = '28000'; end if;
  select count(*) into owned from public.organizations where created_by = uid;
  if owned >= 5 then raise exception 'Organization limit reached' using errcode = 'check_violation'; end if;

  insert into public.organizations (name, slug, type, created_by)
  values (btrim(p_name), p_slug, p_type, uid) returning id into org;
  insert into public.memberships (organization_id, user_id, role) values (org, uid, 'owner');
  insert into public.brands (organization_id, name, slug, is_default)
  values (org, btrim(p_name), 'default', true);
  insert into public.audit_log (organization_id, actor_user_id, action, target_type, target_id)
  values (org, uid, 'organizations.create', 'organizations', org::text);
  return org;
end $$;
revoke all on function public.create_organization(text, text, public.org_type) from public, anon;
grant execute on function public.create_organization(text, text, public.org_type) to authenticated;
