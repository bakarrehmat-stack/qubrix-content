-- 0005: audit log + usage ledger (both append-only for API roles)
create table public.audit_log (
  id              bigint generated always as identity primary key,
  organization_id uuid,   -- deliberately NOT a foreign key: audit history must outlive the organization
  actor_user_id   uuid,
  action          text not null,
  target_type     text,
  target_id       text,
  metadata        jsonb not null default '{}'::jsonb,
  created_at      timestamptz not null default now()
);
create index audit_org_idx on public.audit_log(organization_id, created_at desc);

-- Raw events, never totals: future plans/limits/invoices are just queries over this ledger.
create table public.usage_events (
  id              bigint generated always as identity primary key,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  brand_id        uuid references public.brands(id) on delete set null,
  project_id      uuid references public.projects(id) on delete set null,
  actor_user_id   uuid,
  event_type      text not null check (event_type in (
    'video_uploaded', 'video_minutes_transcribed', 'ai_tokens_used', 'render_seconds', 'clip_downloaded')),
  quantity        numeric not null check (quantity >= 0),
  unit            text not null,
  metadata        jsonb not null default '{}'::jsonb,
  occurred_at     timestamptz not null default now()
);
create index usage_org_time_idx on public.usage_events(organization_id, occurred_at desc);

-- Automatic audit trail for brands and projects.
create or replace function private.audit_row() returns trigger
language plpgsql security definer set search_path = '' as $$
declare r jsonb := to_jsonb(coalesce(new, old));
begin
  insert into public.audit_log (organization_id, actor_user_id, action, target_type, target_id)
  values ((r->>'organization_id')::uuid, (select auth.uid()),
          tg_table_name || '.' || lower(tg_op), tg_table_name, r->>'id');
  return coalesce(new, old);
end $$;
create trigger brands_audit   after insert or update or delete on public.brands
  for each row execute function private.audit_row();
create trigger projects_audit after insert or update or delete on public.projects
  for each row execute function private.audit_row();
