-- 0006: deny by default. Table grants (coarse) + RLS policies (row-level).
alter table public.profiles        enable row level security;
alter table public.platform_admins enable row level security;
alter table public.organizations   enable row level security;
alter table public.memberships     enable row level security;
alter table public.brands          enable row level security;
alter table public.projects        enable row level security;
alter table public.audit_log       enable row level security;
alter table public.usage_events    enable row level security;

-- Start from nothing, then grant only what each table needs.
revoke all on public.profiles, public.platform_admins, public.organizations, public.memberships,
              public.brands, public.projects, public.audit_log, public.usage_events
  from anon, authenticated;

grant select on public.organizations, public.memberships, public.projects, public.brands,
                public.audit_log, public.usage_events to authenticated;
grant select on public.profiles to authenticated;
grant update (display_name) on public.profiles      to authenticated;
grant update (name)         on public.organizations to authenticated;
grant insert (organization_id, name, slug)          on public.brands to authenticated;
grant update (name)                                 on public.brands to authenticated;
grant delete                                        on public.brands to authenticated;
grant insert (organization_id, brand_id, name, created_by) on public.projects to authenticated;
grant update (name, status)                         on public.projects to authenticated;
grant delete                                        on public.projects to authenticated;
-- platform_admins, audit_log writes, usage_events writes, org/membership inserts: no grants at all.

create policy profiles_select_own on public.profiles for select to authenticated
  using (id = (select auth.uid()));
create policy profiles_update_own on public.profiles for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));

create policy orgs_select on public.organizations for select to authenticated
  using (private.is_org_member(id));
create policy orgs_update on public.organizations for update to authenticated
  using (private.has_org_role(id, array['owner','admin']::public.org_role[]))
  with check (private.has_org_role(id, array['owner','admin']::public.org_role[]));

create policy memberships_select on public.memberships for select to authenticated
  using (private.is_org_member(organization_id));

create policy brands_select on public.brands for select to authenticated
  using (private.can_access_brand(id));
create policy brands_insert on public.brands for insert to authenticated
  with check (private.has_org_role(organization_id, array['owner','admin']::public.org_role[]) and not is_default);
create policy brands_update on public.brands for update to authenticated
  using (private.has_org_role(organization_id, array['owner','admin']::public.org_role[]))
  with check (private.has_org_role(organization_id, array['owner','admin']::public.org_role[]));
create policy brands_delete on public.brands for delete to authenticated
  using (private.has_org_role(organization_id, array['owner','admin']::public.org_role[]) and not is_default);

create policy projects_select on public.projects for select to authenticated
  using (private.can_access_brand(brand_id));
create policy projects_insert on public.projects for insert to authenticated
  with check (private.has_org_role(organization_id, array['owner','admin','editor']::public.org_role[])
              and created_by = (select auth.uid()));
create policy projects_update on public.projects for update to authenticated
  using (private.has_org_role(organization_id, array['owner','admin','editor']::public.org_role[]))
  with check (private.has_org_role(organization_id, array['owner','admin','editor']::public.org_role[]));
create policy projects_delete on public.projects for delete to authenticated
  using (private.has_org_role(organization_id, array['owner','admin']::public.org_role[]));

create policy audit_select on public.audit_log for select to authenticated
  using (organization_id is not null and private.has_org_role(organization_id, array['owner','admin']::public.org_role[]));
create policy usage_select on public.usage_events for select to authenticated
  using (private.is_org_member(organization_id));

-- Functions in "private": callable by logged-in users (needed by policies), never by anon.
revoke all on all functions in schema private from public, anon;
grant execute on all functions in schema private to authenticated;
