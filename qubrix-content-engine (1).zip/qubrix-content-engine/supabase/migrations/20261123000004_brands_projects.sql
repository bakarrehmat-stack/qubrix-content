-- 0004: brand profiles + projects
create table public.brands (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name            text not null check (length(name) between 1 and 100),
  slug            text not null check (slug ~ '^[a-z0-9][a-z0-9-]{0,48}[a-z0-9]$'),
  is_default      boolean not null default false,
  settings        jsonb not null default '{}'::jsonb,  -- reserved for the future brand kit
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (organization_id, slug),
  unique (id, organization_id)                          -- target for the composite FK below
);
create unique index one_default_brand_per_org on public.brands(organization_id) where is_default;
create trigger brands_updated before update on public.brands
  for each row execute function private.set_updated_at();

-- Only agencies may have more than one brand.
create or replace function private.enforce_brand_limit() returns trigger
language plpgsql security definer set search_path = '' as $$
declare t public.org_type;
begin
  select type into t from public.organizations where id = new.organization_id;
  if t <> 'agency' and exists (select 1 from public.brands where organization_id = new.organization_id) then
    raise exception 'Only agency organizations can have more than one brand' using errcode = 'check_violation';
  end if;
  return new;
end $$;
create trigger brands_limit before insert on public.brands
  for each row execute function private.enforce_brand_limit();

create table public.projects (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  brand_id        uuid not null,
  name            text not null check (length(name) between 1 and 150),
  status          text not null default 'active' check (status in ('active', 'archived')),
  created_by      uuid references auth.users(id) on delete set null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  -- a project can never point at a brand from a different organization
  foreign key (brand_id, organization_id) references public.brands(id, organization_id) on delete cascade
);
create index projects_org_idx   on public.projects(organization_id);
create index projects_brand_idx on public.projects(brand_id);
create trigger projects_updated before update on public.projects
  for each row execute function private.set_updated_at();

-- THE seam for future agency subclients: every brand/project policy goes through this function.
-- Later, add a brand_members table and extend ONLY this function.
create or replace function private.can_access_brand(brand uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.brands b
                 where b.id = brand and private.is_org_member(b.organization_id))
$$;
