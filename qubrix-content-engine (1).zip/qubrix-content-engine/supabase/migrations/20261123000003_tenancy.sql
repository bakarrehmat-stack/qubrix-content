-- 0003: organizations (tenants) + memberships
create type public.org_type   as enum ('creator', 'business', 'agency');
create type public.org_role   as enum ('owner', 'admin', 'editor', 'viewer');
create type public.org_status as enum ('active', 'suspended');

create table public.organizations (
  id         uuid primary key default gen_random_uuid(),
  name       text not null check (length(name) between 1 and 100),
  slug       text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,48}[a-z0-9]$'),
  type       public.org_type not null,
  status     public.org_status not null default 'active',
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger organizations_updated before update on public.organizations
  for each row execute function private.set_updated_at();

create table public.memberships (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id         uuid not null references auth.users(id) on delete cascade,
  role            public.org_role not null,
  created_at      timestamptz not null default now(),
  primary key (organization_id, user_id)
);
create index memberships_user_idx on public.memberships(user_id);

-- Access helpers. SECURITY DEFINER lets them read memberships without recursing into RLS.
-- Suspended organizations lock everyone out.
create or replace function private.is_org_member(org uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.memberships m
    join public.organizations o on o.id = m.organization_id
    where m.organization_id = org and m.user_id = (select auth.uid()) and o.status = 'active')
$$;

create or replace function private.has_org_role(org uuid, roles public.org_role[]) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.memberships m
    join public.organizations o on o.id = m.organization_id
    where m.organization_id = org and m.user_id = (select auth.uid())
      and o.status = 'active' and m.role = any(roles))
$$;
