-- 0001: shared helpers. "private" is NOT exposed through the Supabase API.
create schema if not exists private;
grant usage on schema private to authenticated;

create or replace function private.set_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end $$;
