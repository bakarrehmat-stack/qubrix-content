'use server';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { requireUser } from '@/lib/auth/session';
import { env } from '@/lib/env';
import { credentialsSchema, emailOnlySchema, formString, newPasswordSchema } from '@/lib/validation/schemas';

const callback = (next: string) => `${env.NEXT_PUBLIC_SITE_URL}/auth/callback?next=${encodeURIComponent(next)}`;

export async function signUp(fd: FormData) {
  const p = credentialsSchema.safeParse({ email: formString(fd, 'email'), password: formString(fd, 'password') });
  if (!p.success) redirect('/signup?e=invalid');
  const supabase = await createClient();
  const { error } = await supabase.auth.signUp({ email: p.data.email, password: p.data.password, options: { emailRedirectTo: callback('/app') } });
  if (error) redirect('/signup?e=failed');
  redirect('/login?m=check-email'); // same message whether or not the email already existed
}

export async function signIn(fd: FormData) {
  const p = credentialsSchema.safeParse({ email: formString(fd, 'email'), password: formString(fd, 'password') });
  if (!p.success) redirect('/login?e=invalid');
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(p.data);
  if (error) redirect('/login?e=invalid'); // never say which part was wrong
  redirect('/app');
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect('/login');
}

export async function requestPasswordReset(fd: FormData) {
  const p = emailOnlySchema.safeParse({ email: formString(fd, 'email') });
  if (p.success) {
    const supabase = await createClient();
    await supabase.auth.resetPasswordForEmail(p.data.email, { redirectTo: callback('/reset-password') });
  }
  redirect('/forgot-password?m=sent'); // identical response either way: no account enumeration
}

export async function updatePassword(fd: FormData) {
  await requireUser();
  const p = newPasswordSchema.safeParse({ password: formString(fd, 'password') });
  if (!p.success) redirect('/reset-password?e=invalid');
  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: p.data.password });
  if (error) redirect('/reset-password?e=failed');
  redirect('/app');
}
