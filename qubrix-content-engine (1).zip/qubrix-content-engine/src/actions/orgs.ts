'use server';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { requireUser } from '@/lib/auth/session';
import { formString, orgSchema, randomSuffix, slugify } from '@/lib/validation/schemas';

export async function createOrganizationAction(fd: FormData) {
  await requireUser();
  const p = orgSchema.safeParse({ name: formString(fd, 'name'), type: formString(fd, 'type') });
  if (!p.success) redirect('/onboarding?e=invalid');
  const supabase = await createClient();
  let slug = '', failure = 'failed';
  for (let i = 0; i < 3; i++) {
    slug = `${slugify(p.data.name, 'org')}-${randomSuffix()}`;
    const { error } = await supabase.rpc('create_organization', { p_name: p.data.name, p_slug: slug, p_type: p.data.type });
    if (!error) redirect(`/app/${slug}`);
    if (error.code === '23505') continue; // slug collision: try another suffix
    failure = /limit/i.test(error.message) ? 'limit' : 'failed';
    break;
  }
  redirect(`/onboarding?e=${failure}`);
}
