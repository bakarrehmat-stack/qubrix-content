'use server';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { requireOrgAccess } from '@/lib/dal/organizations';
import { createBrand } from '@/lib/dal/brands';
import { ForbiddenError } from '@/lib/errors';
import { brandSchema, formString } from '@/lib/validation/schemas';

export async function createBrandAction(fd: FormData) {
  const p = brandSchema.safeParse({ orgSlug: formString(fd, 'orgSlug'), name: formString(fd, 'name') });
  if (!p.success) redirect(`/app/${encodeURIComponent(formString(fd, 'orgSlug'))}/brands?e=invalid`);
  const access = await requireOrgAccess(p.data.orgSlug); // re-verified on every action
  let result = '';
  try { await createBrand(access, p.data.name); } catch (e) { result = e instanceof ForbiddenError ? 'forbidden' : 'failed'; }
  revalidatePath(`/app/${access.org.slug}/brands`);
  redirect(`/app/${access.org.slug}/brands${result ? `?e=${result}` : ''}`);
}
