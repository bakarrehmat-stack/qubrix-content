'use server';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { requireOrgAccess } from '@/lib/dal/organizations';
import { createProject, setProjectStatus } from '@/lib/dal/projects';
import { ForbiddenError } from '@/lib/errors';
import { formString, projectSchema, projectStatusSchema } from '@/lib/validation/schemas';

const back = (slug: string, result: string) => `/app/${slug}/projects${result ? `?e=${result}` : ''}`;
const classify = (e: unknown) => (e instanceof ForbiddenError ? 'forbidden' : 'failed');

export async function createProjectAction(fd: FormData) {
  const p = projectSchema.safeParse({ orgSlug: formString(fd, 'orgSlug'), brandId: formString(fd, 'brandId'), name: formString(fd, 'name') });
  if (!p.success) redirect(back(encodeURIComponent(formString(fd, 'orgSlug')), 'invalid'));
  const access = await requireOrgAccess(p.data.orgSlug);
  let result = '';
  try { await createProject(access, p.data.brandId, p.data.name); } catch (e) { result = classify(e); }
  revalidatePath(back(access.org.slug, ''));
  redirect(back(access.org.slug, result));
}

export async function setProjectStatusAction(fd: FormData) {
  const p = projectStatusSchema.safeParse({ orgSlug: formString(fd, 'orgSlug'), id: formString(fd, 'id'), status: formString(fd, 'status') });
  if (!p.success) redirect(back(encodeURIComponent(formString(fd, 'orgSlug')), 'invalid'));
  const access = await requireOrgAccess(p.data.orgSlug);
  let result = '';
  try { await setProjectStatus(access, p.data.id, p.data.status); } catch (e) { result = classify(e); }
  revalidatePath(back(access.org.slug, ''));
  redirect(back(access.org.slug, result));
}
