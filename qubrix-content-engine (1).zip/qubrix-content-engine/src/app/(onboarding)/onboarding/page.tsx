import { createOrganizationAction } from '@/actions/orgs';
import { requireUser } from '@/lib/auth/session';
import { Alert, AuthShell, buttonCls, inputCls } from '@/components/ui';

export default async function Onboarding({ searchParams }: { searchParams: Promise<{ e?: string }> }) {
  await requireUser();
  const { e } = await searchParams;
  return (
    <AuthShell title="Set up your workspace">
      <Alert code={e} />
      <form action={createOrganizationAction} className="space-y-3">
        <input name="name" required maxLength={100} placeholder="Workspace name" className={inputCls} />
        <select name="type" required defaultValue="creator" className={inputCls}>
          <option value="creator">Creator - I make my own content</option>
          <option value="business">Business - content for my company</option>
          <option value="agency">Agency - I manage several brands</option>
        </select>
        <button className={buttonCls + ' w-full'}>Create workspace</button>
      </form>
    </AuthShell>
  );
}
