import Link from 'next/link';
import { buttonCls, ghostCls } from '@/components/ui';

export default function Home() {
  return (
    <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center px-4 text-center">
      <h1 className="text-3xl font-bold">Qubrix Content Engine</h1>
      <p className="mt-3 text-slate-600">Turn long videos into short, ready-to-post clips.</p>
      <div className="mt-6 flex justify-center gap-3">
        <Link href="/signup" className={buttonCls}>Create account</Link>
        <Link href="/login" className={ghostCls + ' py-2 text-sm'}>Log in</Link>
      </div>
    </main>
  );
}
