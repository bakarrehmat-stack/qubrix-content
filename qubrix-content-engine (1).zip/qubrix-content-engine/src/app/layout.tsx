import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = { title: 'Qubrix Content Engine', description: 'Turn long videos into short clips.' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body className="antialiased">{children}</body></html>;
}
