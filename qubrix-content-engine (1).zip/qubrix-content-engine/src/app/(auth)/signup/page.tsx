import Link from 'next/link';
import { signUp } from '@/actions/auth';
import { Alert, AuthShell, buttonCls, inputCls } from '@/components/ui';

export default async function Signup({ searchParams }: { searchParams: Promise<{ e?: string }> }) {
  const { e } = await searchParams;
  return (
    <AuthShell title="Create your account">
      <Alert code={e} />
      <form action={signUp} className="space-y-3">
        <input name="email" type="email" required autoComplete="email" placeholder="Email" className={inputCls} />
        <input name="password" type="password" required minLength={12} maxLength={72} autoComplete="new-password" placeholder="Password (12+ characters)" className={inputCls} />
        <button className={buttonCls + ' w-full'}>Sign up</button>
      </form>
      <p className="mt-4 text-sm text-slate-600">Already have an account? <Link className="text-indigo-600" href="/login">Log in</Link></p>
    </AuthShell>
  );
}
