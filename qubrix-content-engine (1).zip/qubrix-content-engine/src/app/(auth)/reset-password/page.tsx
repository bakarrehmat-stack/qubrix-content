import { updatePassword } from '@/actions/auth';
import { requireUser } from '@/lib/auth/session';
import { Alert, AuthShell, buttonCls, inputCls } from '@/components/ui';

export default async function Reset({ searchParams }: { searchParams: Promise<{ e?: string }> }) {
  await requireUser(); // only reachable through the emailed link (which creates a session)
  const { e } = await searchParams;
  return (
    <AuthShell title="Choose a new password">
      <Alert code={e} />
      <form action={updatePassword} className="space-y-3">
        <input name="password" type="password" required minLength={12} maxLength={72} autoComplete="new-password" placeholder="New password (12+ characters)" className={inputCls} />
        <button className={buttonCls + ' w-full'}>Save password</button>
      </form>
    </AuthShell>
  );
}
