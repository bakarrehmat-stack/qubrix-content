import Link from 'next/link';
import { signIn } from '@/actions/auth';
import { Alert, AuthShell, buttonCls, inputCls } from '@/components/ui';

export default async function Login({ searchParams }: { searchParams: Promise<{ e?: string; m?: string }> }) {
  const { e, m } = await searchParams;
  return (
    <AuthShell title="Log in">
      <Alert code={e} /><Alert code={m} kind="info" />
      <form action={signIn} className="space-y-3">
        <input name="email" type="email" required autoComplete="email" placeholder="Email" className={inputCls} />
        <input name="password" type="password" required minLength={12} maxLength={72} autoComplete="current-password" placeholder="Password" className={inputCls} />
        <button className={buttonCls + ' w-full'}>Log in</button>
      </form>
      <p className="mt-4 text-sm text-slate-600"><Link className="text-indigo-600" href="/forgot-password">Forgot password?</Link> · <Link className="text-indigo-600" href="/signup">Create account</Link></p>
    </AuthShell>
  );
}
