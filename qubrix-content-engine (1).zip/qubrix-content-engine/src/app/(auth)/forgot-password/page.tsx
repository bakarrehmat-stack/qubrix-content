import Link from 'next/link';
import { requestPasswordReset } from '@/actions/auth';
import { Alert, AuthShell, buttonCls, inputCls } from '@/components/ui';

export default async function Forgot({ searchParams }: { searchParams: Promise<{ m?: string }> }) {
  const { m } = await searchParams;
  return (
    <AuthShell title="Reset your password">
      <Alert code={m} kind="info" />
      <form action={requestPasswordReset} className="space-y-3">
        <input name="email" type="email" required autoComplete="email" placeholder="Email" className={inputCls} />
        <button className={buttonCls + ' w-full'}>Send reset link</button>
      </form>
      <p className="mt-4 text-sm"><Link className="text-indigo-600" href="/login">Back to log in</Link></p>
    </AuthShell>
  );
}
