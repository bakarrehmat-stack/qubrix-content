import { redirect } from 'next/navigation';
import { listMyOrganizations } from '@/lib/dal/organizations';

export default async function AppIndex() {
  const orgs = await listMyOrganizations();
  redirect(orgs.length ? `/app/${orgs[0].slug}` : '/onboarding');
}
