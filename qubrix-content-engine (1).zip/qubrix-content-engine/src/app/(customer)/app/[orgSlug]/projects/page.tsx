import { createProjectAction, setProjectStatusAction } from '@/actions/projects';
import { requireOrgAccess } from '@/lib/dal/organizations';
import { listBrands } from '@/lib/dal/brands';
import { listProjects } from '@/lib/dal/projects';
import { canEditProjects } from '@/lib/auth/roles';
import { Alert, Card, buttonCls, ghostCls, inputCls } from '@/components/ui';

export default async function Projects({ params, searchParams }: { params: Promise<{ orgSlug: string }>; searchParams: Promise<{ e?: string }> }) {
  const access = await requireOrgAccess((await params).orgSlug);
  const { e } = await searchParams;
  const [brands, projects] = await Promise.all([listBrands(access), listProjects(access)]);
  const editable = canEditProjects(access.role);
  return (
    <div className="space-y-4">
      <Alert code={e} />
      {editable && (
        <Card title="New project">
          <form action={createProjectAction} className="flex flex-wrap gap-2">
            <input type="hidden" name="orgSlug" value={access.org.slug} />
            <input name="name" required maxLength={150} placeholder="Project name" className={inputCls + ' flex-1'} />
            <select name="brandId" required className={inputCls + ' w-48'}>{brands.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select>
            <button className={buttonCls}>Create</button>
          </form>
        </Card>
      )}
      <Card title="Projects">
        {projects.length === 0 ? <p className="text-sm text-slate-500">No projects yet.</p> : (
          <ul className="divide-y divide-slate-100 text-sm">
            {projects.map((p) => (
              <li key={p.id} className="flex items-center justify-between py-2">
                <span>{p.name} <span className="text-xs text-slate-500">· {p.brands?.name} · {p.status}</span></span>
                {editable && (
                  <form action={setProjectStatusAction}>
                    <input type="hidden" name="orgSlug" value={access.org.slug} /><input type="hidden" name="id" value={p.id} />
                    <input type="hidden" name="status" value={p.status === 'active' ? 'archived' : 'active'} />
                    <button className={ghostCls}>{p.status === 'active' ? 'Archive' : 'Restore'}</button>
                  </form>
                )}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
