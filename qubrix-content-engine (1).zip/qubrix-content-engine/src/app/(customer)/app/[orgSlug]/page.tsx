import { requireOrgAccess } from '@/lib/dal/organizations';
import { countRows } from '@/lib/dal/projects';
import { Card } from '@/components/ui';

export default async function Overview({ params }: { params: Promise<{ orgSlug: string }> }) {
  const access = await requireOrgAccess((await params).orgSlug);
  const [brands, projects] = await Promise.all([countRows(access, 'brands'), countRows(access, 'projects')]);
  return (
    <div className="grid gap-4 sm:grid-cols-3">
      <Card title="Your role"><p className="text-2xl font-semibold capitalize">{access.role}</p></Card>
      <Card title="Brands"><p className="text-2xl font-semibold">{brands}</p></Card>
      <Card title="Projects"><p className="text-2xl font-semibold">{projects}</p></Card>
    </div>
  );
}
