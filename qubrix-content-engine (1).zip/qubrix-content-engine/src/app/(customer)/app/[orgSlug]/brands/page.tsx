import { createBrandAction } from '@/actions/brands';
import { requireOrgAccess } from '@/lib/dal/organizations';
import { listBrands } from '@/lib/dal/brands';
import { canManageOrg } from '@/lib/auth/roles';
import { Alert, Card, buttonCls, inputCls } from '@/components/ui';

export default async function Brands({ params, searchParams }: { params: Promise<{ orgSlug: string }>; searchParams: Promise<{ e?: string }> }) {
  const access = await requireOrgAccess((await params).orgSlug);
  const { e } = await searchParams;
  const brands = await listBrands(access);
  return (
    <div className="space-y-4">
      <Alert code={e} />
      <Card title="Brand profiles">
        <ul className="divide-y divide-slate-100 text-sm">
          {brands.map((b) => <li key={b.id} className="py-2">{b.name}{b.is_default && <span className="ml-2 text-xs text-slate-500">(default)</span>}</li>)}
        </ul>
      </Card>
      {access.org.type === 'agency' && canManageOrg(access.role) ? (
        <Card title="Add a brand">
          <form action={createBrandAction} className="flex gap-2">
            <input type="hidden" name="orgSlug" value={access.org.slug} />
            <input name="name" required maxLength={100} placeholder="Brand name" className={inputCls} />
            <button className={buttonCls}>Add</button>
          </form>
        </Card>
      ) : (
        <p className="text-sm text-slate-500">{access.org.type === 'agency' ? 'Only owners and admins can add brands.' : 'Only agency workspaces can manage multiple brands.'}</p>
      )}
    </div>
  );
}
