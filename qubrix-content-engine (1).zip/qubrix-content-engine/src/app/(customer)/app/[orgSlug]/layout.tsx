import Link from 'next/link';
import { signOut } from '@/actions/auth';
import { listMyOrganizations, requireOrgAccess } from '@/lib/dal/organizations';
import { ghostCls } from '@/components/ui';

export default async function OrgLayout({ children, params }: { children: React.ReactNode; params: Promise<{ orgSlug: string }> }) {
  const { orgSlug } = await params;
  const { org } = await requireOrgAccess(orgSlug);
  const orgs = await listMyOrganizations();
  const base = `/app/${org.slug}`;
  return (
    <div className="mx-auto max-w-4xl px-4 py-6">
      <header className="mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <p className="text-xs uppercase tracking-wide text-slate-500">{org.type}</p>
          <h1 className="text-xl font-bold">{org.name}</h1>
        </div>
        <nav className="flex items-center gap-4 text-sm">
          <Link href={base}>Overview</Link><Link href={`${base}/brands`}>Brands</Link><Link href={`${base}/projects`}>Projects</Link>
          <form action={signOut}><button className={ghostCls}>Sign out</button></form>
        </nav>
      </header>
      {orgs.length > 1 && (
        <p className="mb-4 text-xs text-slate-500">Switch workspace: {orgs.map((o) => <Link key={o.id} href={`/app/${o.slug}`} className="mr-3 text-indigo-600">{o.name}</Link>)}</p>
      )}
      {children}
    </div>
  );
}
