import { NextResponse, type NextRequest } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { env } from '@/lib/env';

// Only same-site relative paths are allowed (prevents open-redirect attacks).
const safeNext = (n: string | null) => (n && /^\/(?!\/)[\w\-/]*$/.test(n) ? n : '/app');

export async function GET(request: NextRequest) {
  const params = new URL(request.url).searchParams;
  const code = params.get('code');
  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) return NextResponse.redirect(new URL(safeNext(params.get('next')), env.NEXT_PUBLIC_SITE_URL));
  }
  return NextResponse.redirect(new URL('/login?e=callback', env.NEXT_PUBLIC_SITE_URL));
}
