import { requirePlatformAdmin } from '@/lib/auth/session';
import { Card } from '@/components/ui';

export default async function AdminHome() {
  const user = await requirePlatformAdmin(); // checked in the page itself, not only in a layout
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="mb-4 text-2xl font-bold">Super Admin</h1>
      <Card><p className="text-sm text-slate-600">Signed in as {user.email}. The real admin dashboard arrives in Phase 2.</p></Card>
    </main>
  );
}
