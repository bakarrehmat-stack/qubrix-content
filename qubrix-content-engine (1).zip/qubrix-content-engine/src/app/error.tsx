'use client';
export default function Error({ reset }: { error: Error; reset: () => void }) {
  return (
    <main className="mx-auto max-w-md py-24 text-center">
      <h1 className="text-xl font-semibold">Something went wrong</h1>
      <button onClick={reset} className="mt-4 rounded-md bg-indigo-600 px-4 py-2 text-sm text-white">Try again</button>
    </main>
  );
}
