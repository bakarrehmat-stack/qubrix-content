import type { ReactNode } from 'react';

export const inputCls = 'w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500';
export const buttonCls = 'rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-500';
export const ghostCls = 'rounded-md border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50';

const MESSAGES: Record<string, string> = {
  invalid: 'Please check what you entered and try again.',
  failed: 'Something went wrong. Please try again in a moment.',
  forbidden: 'You do not have permission to do that.',
  limit: 'You have reached the organization limit for this account.',
  callback: 'That link is invalid or has expired. Please request a new one.',
  'check-email': 'Check your email to confirm your account, then log in.',
  sent: 'If an account exists for that email, a reset link is on its way.',
};

export function Alert({ code, kind = 'error' }: { code?: string; kind?: 'error' | 'info' }) {
  if (!code) return null;
  const cls = kind === 'info' ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-800';
  return <p role="alert" className={`mb-4 rounded-md px-3 py-2 text-sm ${cls}`}>{MESSAGES[code] ?? MESSAGES.failed}</p>;
}

export function Card({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
      {title && <h2 className="mb-3 text-base font-semibold text-slate-900">{title}</h2>}
      {children}
    </section>
  );
}

export function AuthShell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-4">
      <p className="mb-1 text-sm font-semibold text-indigo-600">Qubrix Content Engine</p>
      <h1 className="mb-6 text-2xl font-bold text-slate-900">{title}</h1>
      {children}
    </main>
  );
}
