import { z } from 'zod';

const email = z.email().max(254).transform((s) => s.trim().toLowerCase());
export const credentialsSchema = z.object({ email, password: z.string().min(12).max(72) });
export const emailOnlySchema = z.object({ email });
export const newPasswordSchema = z.object({ password: z.string().min(12).max(72) });
export const orgSchema = z.object({ name: z.string().trim().min(1).max(100), type: z.enum(['creator', 'business', 'agency']) });
export const brandSchema = z.object({ orgSlug: z.string().min(3).max(60), name: z.string().trim().min(1).max(100) });
export const projectSchema = z.object({ orgSlug: z.string().min(3).max(60), brandId: z.uuid(), name: z.string().trim().min(1).max(150) });
export const projectStatusSchema = z.object({ orgSlug: z.string().min(3).max(60), id: z.uuid(), status: z.enum(['active', 'archived']) });

export function slugify(input: string, fallback: string) {
  const s = input.normalize('NFKD').replace(/[^\x00-\x7F]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40).replace(/-+$/g, '');
  return s.length >= 2 ? s : fallback;
}
export const randomSuffix = () => crypto.randomUUID().replace(/-/g, '').slice(0, 5);
export const formString = (fd: FormData, key: string) => { const v = fd.get(key); return typeof v === 'string' ? v : ''; };
