import 'server-only';
import { createClient } from '@/lib/supabase/server';
import { canManageOrg } from '@/lib/auth/roles';
import { ForbiddenError } from '@/lib/errors';
import { randomSuffix, slugify } from '@/lib/validation/schemas';
import type { OrgAccess } from './organizations';

export interface Brand { id: string; name: string; slug: string; is_default: boolean }

export async function listBrands(a: OrgAccess): Promise<Brand[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from('brands').select('id, name, slug, is_default')
    .eq('organization_id', a.org.id).order('is_default', { ascending: false }).order('created_at');
  if (error) throw new Error('Could not load brands');
  return data as Brand[];
}

export async function createBrand(a: OrgAccess, name: string) {
  if (!canManageOrg(a.role)) throw new ForbiddenError();
  if (a.org.type !== 'agency') throw new ForbiddenError('Only agency accounts can have multiple brands');
  const supabase = await createClient();
  for (let i = 0; i < 3; i++) {
    const slug = i === 0 ? slugify(name, 'brand') : `${slugify(name, 'brand')}-${randomSuffix()}`;
    const { error } = await supabase.from('brands').insert({ organization_id: a.org.id, name, slug });
    if (!error) return;
    if (error.code !== '23505') throw new Error('Could not create brand'); // 23505 = slug already used: retry
  }
  throw new Error('Could not create brand');
}
