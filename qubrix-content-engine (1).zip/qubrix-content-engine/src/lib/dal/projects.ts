import 'server-only';
import { createClient } from '@/lib/supabase/server';
import { canEditProjects } from '@/lib/auth/roles';
import { ForbiddenError } from '@/lib/errors';
import type { OrgAccess } from './organizations';

export interface Project { id: string; name: string; status: 'active' | 'archived'; brand_id: string; brands: { name: string } | null }

export async function listProjects(a: OrgAccess): Promise<Project[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from('projects').select('id, name, status, brand_id, brands(name)')
    .eq('organization_id', a.org.id).order('created_at', { ascending: false });
  if (error) throw new Error('Could not load projects');
  return (data ?? []).map((p: any) => ({ ...p, brands: Array.isArray(p.brands) ? p.brands[0] ?? null : p.brands })) as Project[];
}

export async function createProject(a: OrgAccess, brandId: string, name: string) {
  if (!canEditProjects(a.role)) throw new ForbiddenError();
  const supabase = await createClient();
  // organization_id comes from the verified membership, never from the form.
  const { error } = await supabase.from('projects').insert({ organization_id: a.org.id, brand_id: brandId, name, created_by: a.userId });
  if (error) throw new Error('Could not create project');
}

export async function setProjectStatus(a: OrgAccess, id: string, status: 'active' | 'archived') {
  if (!canEditProjects(a.role)) throw new ForbiddenError();
  const supabase = await createClient();
  const { error } = await supabase.from('projects').update({ status }).eq('id', id).eq('organization_id', a.org.id);
  if (error) throw new Error('Could not update project');
}

export async function countRows(a: OrgAccess, table: 'brands' | 'projects') {
  const supabase = await createClient();
  const { count } = await supabase.from(table).select('id', { count: 'exact', head: true }).eq('organization_id', a.org.id);
  return count ?? 0;
}
