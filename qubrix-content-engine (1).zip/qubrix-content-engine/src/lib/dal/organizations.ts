import 'server-only';
import { cache } from 'react';
import { notFound } from 'next/navigation';
import { requireUser } from '@/lib/auth/session';
import { createClient } from '@/lib/supabase/server';
import type { OrgRole, OrgType } from '@/lib/auth/roles';

export interface Org { id: string; name: string; slug: string; type: OrgType }
export interface OrgAccess { userId: string; org: Org; role: OrgRole }

/** Organizations the current user belongs to (RLS already filters; we also filter by user for clarity). */
export const listMyOrganizations = cache(async (): Promise<(Org & { role: OrgRole })[]> => {
  const user = await requireUser();
  const supabase = await createClient();
  const { data, error } = await supabase.from('memberships').select('role, organizations(id, name, slug, type)').eq('user_id', user.id);
  if (error) throw new Error('Could not load organizations');
  return (data ?? []).flatMap((row: any) => {
    const o = Array.isArray(row.organizations) ? row.organizations[0] : row.organizations;
    return o ? [{ ...(o as Org), role: row.role as OrgRole }] : [];
  });
});

/** Every org-scoped page and action starts here. Non-members get a 404 (we don't reveal what exists). */
export const requireOrgAccess = cache(async (slug: string): Promise<OrgAccess> => {
  const user = await requireUser();
  const supabase = await createClient();
  const { data: org } = await supabase.from('organizations').select('id, name, slug, type').eq('slug', slug).maybeSingle();
  if (!org) notFound();
  const { data: m } = await supabase.from('memberships').select('role').eq('organization_id', org.id).eq('user_id', user.id).maybeSingle();
  if (!m) notFound();
  return { userId: user.id, org: org as Org, role: m.role as OrgRole };
});
