export class ForbiddenError extends Error {
  constructor(message = 'You do not have permission to do that') { super(message); this.name = 'ForbiddenError'; }
}
