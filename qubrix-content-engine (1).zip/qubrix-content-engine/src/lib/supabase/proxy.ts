import { createServerClient } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';
import { env } from '@/lib/env';

const PROTECTED = ['/app', '/admin', '/onboarding'];
const AUTH_PAGES = ['/login', '/signup', '/forgot-password'];
const isUnder = (path: string, base: string) => path === base || path.startsWith(base + '/');

/** Refreshes the login session cookie and does coarse redirects. NOT the security boundary. */
export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request });
  const supabase = createServerClient(env.NEXT_PUBLIC_SUPABASE_URL, env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY, {
    cookies: {
      getAll: () => request.cookies.getAll(),
      setAll(list) {
        list.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        list.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
      },
    },
  });
  const { data: { user } } = await supabase.auth.getUser(); // validated with the Auth server
  const path = request.nextUrl.pathname;

  if (!user && PROTECTED.some((p) => isUnder(path, p))) return NextResponse.redirect(new URL('/login', request.url));
  if (user && AUTH_PAGES.includes(path)) return NextResponse.redirect(new URL('/app', request.url));
  return response;
}
