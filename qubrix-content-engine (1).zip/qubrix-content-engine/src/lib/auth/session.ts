import 'server-only';
import { cache } from 'react';
import { notFound, redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

/** The logged-in user, verified with the Supabase Auth server (never trust cookies alone). */
export const getUser = cache(async () => {
  const supabase = await createClient();
  const { data } = await supabase.auth.getUser();
  return data.user;
});

export async function requireUser() {
  const user = await getUser();
  if (!user) redirect('/login');
  return user;
}

/** Super Admin check, done in the database. Shows a 404 (not "forbidden") to everyone else. */
export const requirePlatformAdmin = cache(async () => {
  const user = await requireUser();
  const supabase = await createClient();
  const { data } = await supabase.rpc('am_i_platform_admin');
  if (data !== true) notFound();
  return user;
});
