export type OrgRole = 'owner' | 'admin' | 'editor' | 'viewer';
export type OrgType = 'creator' | 'business' | 'agency';
export const canManageOrg = (r: OrgRole) => r === 'owner' || r === 'admin';
export const canEditProjects = (r: OrgRole) => r === 'owner' || r === 'admin' || r === 'editor';
