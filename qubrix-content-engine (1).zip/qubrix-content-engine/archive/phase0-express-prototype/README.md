# Qubrix Content Engine

## Roadmap
- **Phase 1 (this repo):** config, auth, secure DB, protected content CRUD
- Phase 2+: not started (e.g. content generation, workflows, front-end)

## Architecture
```
qubrix-content-engine/
├── src/
│   ├── config.js          # loads + validates .env (app refuses to start if invalid)
│   ├── db.js              # SQLite connection, schema, constraints
│   ├── server.js          # Express app: helmet, rate limits, error handling
│   ├── middleware/auth.js # verifies JWT, loads user
│   └── routes/
│       ├── auth.js        # register / login / me
│       └── content.js     # content CRUD (owner-only)
├── scripts/demo.js        # automated end-to-end check
├── data/                  # SQLite file lives here (git-ignored)
├── .env.example           # template; real .env is git-ignored
└── package.json
```

## Security in Phase 1
- Passwords hashed with bcrypt (cost 12); 10-72 char rule; no plaintext stored
- JWT (HS256, 1h expiry) sent as `Authorization: Bearer <token>`; secret must be 32+ chars
- Rate limiting: 20 auth attempts / 15 min, 120 requests / min overall
- Every DB query is parameterized (no SQL injection) and scoped to the logged-in user
- DB constraints: foreign keys on, length and status CHECKs
- Input validated with zod; helmet security headers; 100kb body limit; no stack traces to clients
- Secrets only in `.env` (git-ignored)

## Run locally (step by step)
1. **Install Node.js** (version 18 or newer, LTS recommended) from https://nodejs.org. Check: `node -v`
2. **Open a terminal in the project folder:** `cd qubrix-content-engine`
3. **Install dependencies:** `npm install`
4. **Create your env file:**
   - Mac/Linux: `cp .env.example .env`
   - Windows (PowerShell): `copy .env.example .env`
5. **Generate a secret:** `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
   Copy the output, open `.env`, and paste it after `JWT_SECRET=`
6. **Start the server:** `npm start` -> you should see `Qubrix Content Engine running on http://localhost:3000`
7. **Test it** (open a SECOND terminal, same folder): `npm run demo` -> every line should say `PASS`
8. Health check in your browser: http://localhost:3000/health

## API
| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | /api/auth/register | no | `{email, password}` -> token |
| POST | /api/auth/login | no | `{email, password}` -> token |
| GET | /api/auth/me | yes | current user |
| GET/POST | /api/content | yes | list / create |
| GET/PATCH/DELETE | /api/content/:id | yes | read / update / delete (own items only) |

## Troubleshooting
- `Invalid or missing environment variables` -> `.env` is missing or JWT_SECRET is empty/short
- `EADDRINUSE` -> port taken; change `PORT` in `.env`
- `better-sqlite3` install errors -> use Node LTS; on Windows install "Build Tools" only if prompted
