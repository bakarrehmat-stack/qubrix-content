// Beginner-friendly end-to-end check. Run the server first, then: npm run demo
require('dotenv').config();
const base = `http://localhost:${process.env.PORT || 3000}`;
const call = async (method, path, body, token) => {
  const r = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...(token && { Authorization: `Bearer ${token}` }) }, body: body && JSON.stringify(body) });
  return { status: r.status, data: r.status === 204 ? null : await r.json() };
};
const check = (label, ok) => { console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}`); if (!ok) process.exitCode = 1; };
(async () => {
  const a = `demo${Date.now()}@example.com`, b = `other${Date.now()}@example.com`, pw = 'a-long-demo-password';
  const ra = await call('POST', '/api/auth/register', { email: a, password: pw });
  check('register user A', ra.status === 201);
  const rb = await call('POST', '/api/auth/register', { email: b, password: pw });
  const ta = ra.data.token, tb = rb.data.token;
  check('weak password rejected', (await call('POST', '/api/auth/register', { email: 'x@example.com', password: 'short' })).status === 400);
  check('wrong password rejected', (await call('POST', '/api/auth/login', { email: a, password: 'wrong-password-123' })).status === 401);
  check('login works', (await call('POST', '/api/auth/login', { email: a, password: pw })).status === 200);
  check('content without token -> 401', (await call('GET', '/api/content')).status === 401);
  const c = await call('POST', '/api/content', { title: 'Hello Qubrix', body: 'First piece' }, ta);
  check('create content', c.status === 201);
  check('update content', (await call('PATCH', `/api/content/${c.data.id}`, { status: 'published' }, ta)).data.status === 'published');
  check("user B cannot read A's content", (await call('GET', `/api/content/${c.data.id}`, null, tb)).status === 404);
  check('SQL-injection-style id rejected', (await call('GET', '/api/content/1%20OR%201=1', null, ta)).status === 400);
  check('delete content', (await call('DELETE', `/api/content/${c.data.id}`, null, ta)).status === 204);
})().catch((e) => { console.error('Could not reach server. Is it running? ->', e.message); process.exit(1); });
