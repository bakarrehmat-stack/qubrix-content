const express = require('express');
const { z } = require('zod');
const db = require('../db');
const requireAuth = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

const create = z.object({
  title: z.string().trim().min(1).max(200),
  body: z.string().max(50000).default(''),
  status: z.enum(['draft', 'published', 'archived']).default('draft'),
});
const update = create.partial().refine((o) => Object.keys(o).length > 0, 'Nothing to update');
const idParam = z.coerce.number().int().positive();

// Every query is parameterized AND scoped by user_id (no cross-user access).
router.get('/', (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 20, 100);
  const offset = Math.max(Number(req.query.offset) || 0, 0);
  const rows = db.prepare('SELECT * FROM content WHERE user_id = ? ORDER BY id DESC LIMIT ? OFFSET ?').all(req.user.id, limit, offset);
  res.json({ items: rows, limit, offset });
});

router.post('/', (req, res) => {
  const p = create.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: p.error.issues[0].message });
  const { title, body, status } = p.data;
  const info = db.prepare('INSERT INTO content (user_id, title, body, status) VALUES (?,?,?,?)').run(req.user.id, title, body, status);
  res.status(201).json(db.prepare('SELECT * FROM content WHERE id = ?').get(info.lastInsertRowid));
});

router.param('id', (req, res, next, v) => {
  const p = idParam.safeParse(v);
  if (!p.success) return res.status(400).json({ error: 'Invalid id' });
  req.contentId = p.data;
  next();
});
const find = (req) => db.prepare('SELECT * FROM content WHERE id = ? AND user_id = ?').get(req.contentId, req.user.id);

router.get('/:id', (req, res) => {
  const row = find(req);
  row ? res.json(row) : res.status(404).json({ error: 'Not found' });
});

router.patch('/:id', (req, res) => {
  const p = update.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: p.error.issues[0].message });
  const row = find(req);
  if (!row) return res.status(404).json({ error: 'Not found' });
  const m = { ...row, ...p.data };
  db.prepare("UPDATE content SET title=?, body=?, status=?, updated_at=datetime('now') WHERE id=? AND user_id=?")
    .run(m.title, m.body, m.status, row.id, req.user.id);
  res.json(find(req));
});

router.delete('/:id', (req, res) => {
  const r = db.prepare('DELETE FROM content WHERE id = ? AND user_id = ?').run(req.contentId, req.user.id);
  r.changes ? res.status(204).end() : res.status(404).json({ error: 'Not found' });
});

module.exports = router;
