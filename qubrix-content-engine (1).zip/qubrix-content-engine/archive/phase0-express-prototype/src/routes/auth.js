const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { z } = require('zod');
const config = require('../config');
const db = require('../db');
const requireAuth = require('../middleware/auth');

const router = express.Router();
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many attempts. Try again later.' } });

const creds = z.object({
  email: z.string().trim().toLowerCase().email().max(254),
  password: z.string().min(10, 'Password must be at least 10 characters').max(72),
});
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing', 12);
const sign = (id) => jwt.sign({ sub: String(id) }, config.JWT_SECRET, { algorithm: 'HS256', expiresIn: config.JWT_EXPIRES_IN });

router.post('/register', limiter, (req, res) => {
  if (!config.ALLOW_REGISTRATION) return res.status(403).json({ error: 'Registration is closed' });
  const p = creds.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: p.error.issues[0].message });
  const { email, password } = p.data;
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email))
    return res.status(409).json({ error: 'Email already registered' });
  const info = db.prepare('INSERT INTO users (email, password_hash) VALUES (?, ?)').run(email, bcrypt.hashSync(password, 12));
  res.status(201).json({ token: sign(info.lastInsertRowid), user: { id: info.lastInsertRowid, email } });
});

router.post('/login', limiter, (req, res) => {
  const p = creds.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Invalid email or password format' });
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(p.data.email);
  const ok = bcrypt.compareSync(p.data.password, user ? user.password_hash : DUMMY_HASH); // constant-ish timing
  if (!user || !ok) return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ token: sign(user.id), user: { id: user.id, email: user.email } });
});

router.get('/me', requireAuth, (req, res) => res.json({ user: req.user }));

module.exports = router;
