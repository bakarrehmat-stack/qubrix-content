// Tenant-isolation gate. Talks to the REAL database, impersonating users the same way Supabase does.
import { Client } from 'pg';
import { randomUUID } from 'node:crypto';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

const db = new Client({
  connectionString: process.env.TEST_DATABASE_URL ?? 'postgresql://postgres:postgres@127.0.0.1:54322/postgres',
});
type Q = (sql: string, params?: unknown[]) => Promise<{ rows: any[]; rowCount: number | null }>;

/** Run `fn` as a logged-in user (or anonymous when uid is null). Rolls back unless commit=true. */
async function as<T>(uid: string | null, fn: (q: Q) => Promise<T>, commit = false): Promise<T> {
  await db.query('begin');
  try {
    await db.query(`set local role ${uid ? 'authenticated' : 'anon'}`);
    if (uid) {
      await db.query(`select set_config('request.jwt.claims', $1, true), set_config('request.jwt.claim.sub', $2, true)`,
        [JSON.stringify({ sub: uid, role: 'authenticated' }), uid]);
    }
    return await fn((s, p) => db.query(s, p));
  } finally {
    await db.query(commit ? 'commit' : 'rollback');
  }
}

const tag = randomUUID().slice(0, 8);
const A = randomUUID(); // owner of org A (creator)
const B = randomUUID(); // owner of org B (agency)
const C = randomUUID(); // viewer in org A
const D = randomUUID(); // logged-in stranger, no memberships
let orgA = '', orgB = '', brandA = '', brandB = '', projA = '';

const newOrg = (uid: string, name: string, slug: string, type: string) =>
  as(uid, async (q) => (await q('select public.create_organization($1,$2,$3) as id', [name, slug, type])).rows[0].id as string, true);

beforeAll(async () => {
  await db.connect();
  for (const [id, n] of [[A, 'a'], [B, 'b'], [C, 'c'], [D, 'd']]) {
    await db.query('insert into auth.users (id, email) values ($1, $2)', [id, `${n}-${tag}@example.com`]);
  }
  orgA = await newOrg(A, 'Org A', `org-a-${tag}`, 'creator');
  orgB = await newOrg(B, 'Org B', `org-b-${tag}`, 'agency');
  await db.query(`insert into public.memberships (organization_id, user_id, role) values ($1, $2, 'viewer')`, [orgA, C]);
  brandA = (await db.query('select id from public.brands where organization_id = $1', [orgA])).rows[0].id;
  brandB = (await db.query('select id from public.brands where organization_id = $1', [orgB])).rows[0].id;
  projA = await as(A, async (q) => (await q(
    `insert into public.projects (organization_id, brand_id, name, created_by) values ($1,$2,'Secret A project',$3) returning id`,
    [orgA, brandA, A])).rows[0].id, true);
});

afterAll(async () => {
  await db.query('delete from public.organizations where id = any($1)', [[orgA, orgB]]);
  await db.query('delete from public.audit_log where actor_user_id = any($1)', [[A, B, C, D]]);
  await db.query('delete from auth.users where id = any($1)', [[A, B, C, D]]);
  await db.end();
});

describe('creating organizations', () => {
  it('creates owner membership and a default brand automatically', async () => {
    const r = await as(A, (q) => q('select role from public.memberships where organization_id = $1 and user_id = $2', [orgA, A]));
    expect(r.rows[0].role).toBe('owner');
    const b = await as(A, (q) => q('select is_default from public.brands where organization_id = $1', [orgA]));
    expect(b.rows).toEqual([{ is_default: true }]);
  });
  it('rejects anonymous callers', async () => {
    await expect(as(null, (q) => q(`select public.create_organization('X','x-${tag}','creator')`))).rejects.toThrow();
  });
  it('rejects direct inserts into organizations and memberships (no self-promotion)', async () => {
    await expect(as(D, (q) => q(`insert into public.organizations (name, slug, type) values ('Hax','hax-${tag}','creator')`))).rejects.toThrow(/permission denied/);
    await expect(as(D, (q) => q(`insert into public.memberships (organization_id, user_id, role) values ($1,$2,'owner')`, [orgA, D]))).rejects.toThrow(/permission denied/);
    await expect(as(C, (q) => q(`update public.memberships set role = 'owner' where user_id = $1`, [C]))).rejects.toThrow(/permission denied/);
  });
  it('limits how many organizations one user can create', async () => {
    const orgs: string[] = [];
    try {
      await expect((async () => {
        for (let i = 0; i < 6; i++) orgs.push(await newOrg(D, `D${i}`, `d${i}-${tag}`, 'creator'));
      })()).rejects.toThrow(/limit/i);
      expect(orgs.length).toBe(5);
    } finally {
      await db.query('delete from public.organizations where created_by = $1', [D]);
    }
  });
});

describe('tenant isolation (user B / D must never see org A)', () => {
  for (const [table, col] of [['organizations', 'id'], ['memberships', 'organization_id'], ['brands', 'organization_id'],
    ['projects', 'organization_id'], ['audit_log', 'organization_id'], ['usage_events', 'organization_id']]) {
    it(`${table}: other tenants see zero rows of org A`, async () => {
      for (const u of [B, D]) {
        const r = await as(u, (q) => q(`select 1 from public.${table} where ${col} = $1`, [orgA]));
        expect(r.rows.length).toBe(0);
      }
    });
  }
  it('owner A can still see their own data', async () => {
    const r = await as(A, (q) => q('select name from public.projects where id = $1', [projA]));
    expect(r.rows[0].name).toBe('Secret A project');
  });
  it('B cannot create a project inside A\'s brand', async () => {
    await expect(as(B, (q) => q(`insert into public.projects (organization_id, brand_id, name, created_by) values ($1,$2,'x',$3)`, [orgA, brandA, B]))).rejects.toThrow(/row-level security/);
  });
  it('B cannot smuggle a project into A via a mismatched brand/org pair', async () => {
    await expect(as(B, (q) => q(`insert into public.projects (organization_id, brand_id, name, created_by) values ($1,$2,'x',$3)`, [orgB, brandA, B]))).rejects.toThrow(/foreign key|row-level security/);
    await expect(as(A, (q) => q(`insert into public.projects (organization_id, brand_id, name, created_by) values ($1,$2,'x',$3)`, [orgA, brandB, A]))).rejects.toThrow(/foreign key|row-level security/);
  });
  it('B cannot update or delete A\'s rows (silently affects 0 rows)', async () => {
    const u = await as(B, (q) => q(`update public.projects set name = 'pwned' where id = $1`, [projA]));
    const d = await as(B, (q) => q('delete from public.projects where id = $1', [projA]));
    expect(u.rowCount).toBe(0);
    expect(d.rowCount).toBe(0);
  });
  it('SQL-injection-style input is treated as data', async () => {
    const r = await as(A, (q) => q('select * from public.projects where name = $1', [`' OR '1'='1`]));
    expect(r.rows.length).toBe(0);
  });
});

describe('roles', () => {
  it('viewer can read but cannot create projects', async () => {
    const r = await as(C, (q) => q('select 1 from public.projects where id = $1', [projA]));
    expect(r.rows.length).toBe(1);
    await expect(as(C, (q) => q(`insert into public.projects (organization_id, brand_id, name, created_by) values ($1,$2,'v',$3)`, [orgA, brandA, C]))).rejects.toThrow(/row-level security/);
  });
  it('project creator must be the caller (no forged created_by)', async () => {
    await expect(as(A, (q) => q(`insert into public.projects (organization_id, brand_id, name, created_by) values ($1,$2,'f',$3)`, [orgA, brandA, B]))).rejects.toThrow(/row-level security/);
  });
  it('viewer cannot read the audit log; owner can', async () => {
    expect((await as(C, (q) => q('select 1 from public.audit_log where organization_id = $1', [orgA]))).rows.length).toBe(0);
    expect((await as(A, (q) => q('select 1 from public.audit_log where organization_id = $1', [orgA]))).rows.length).toBeGreaterThan(0);
  });
  it('only owners/admins rename an org, and the slug can never change', async () => {
    expect((await as(C, (q) => q(`update public.organizations set name='n' where id = $1`, [orgA]))).rowCount).toBe(0);
    expect((await as(A, (q) => q(`update public.organizations set name='Org A2' where id = $1`, [orgA]))).rowCount).toBe(1);
    await expect(as(A, (q) => q(`update public.organizations set slug='stolen-${tag}' where id = $1`, [orgA]))).rejects.toThrow(/permission denied/);
    await expect(as(A, (q) => q(`update public.organizations set status='suspended' where id = $1`, [orgA]))).rejects.toThrow(/permission denied/);
  });
});

describe('brands', () => {
  it('a creator organization cannot add a second brand', async () => {
    await expect(as(A, (q) => q(`insert into public.brands (organization_id, name, slug) values ($1,'Two','two')`, [orgA]))).rejects.toThrow(/agency/);
  });
  it('an agency can add several brands, but cannot delete its default brand', async () => {
    await as(B, (q) => q(`insert into public.brands (organization_id, name, slug) values ($1,'Client 1','client-1')`, [orgB]), true);
    await as(B, (q) => q(`insert into public.brands (organization_id, name, slug) values ($1,'Client 2','client-2')`, [orgB]), true);
    expect((await as(B, (q) => q('select 1 from public.brands where organization_id = $1', [orgB]))).rows.length).toBe(3);
    expect((await as(B, (q) => q('delete from public.brands where id = $1', [brandB]))).rowCount).toBe(0);
  });
  it('cannot create a second default brand or edit the reserved settings column', async () => {
    await expect(as(B, (q) => q(`insert into public.brands (organization_id, name, slug, is_default) values ($1,'D','dd',true)`, [orgB]))).rejects.toThrow(/permission denied|row-level security/);
    await expect(as(B, (q) => q(`update public.brands set settings = '{"x":1}' where id = $1`, [brandB]))).rejects.toThrow(/permission denied/);
  });
});

describe('append-only ledgers, admin table, anonymous access, suspension', () => {
  it('nobody can write audit_log or usage_events through the API', async () => {
    await expect(as(A, (q) => q(`insert into public.audit_log (action) values ('forged')`))).rejects.toThrow(/permission denied/);
    await expect(as(A, (q) => q(`insert into public.usage_events (organization_id,event_type,quantity,unit) values ($1,'render_seconds',1,'s')`, [orgA]))).rejects.toThrow(/permission denied/);
    await expect(as(A, (q) => q('delete from public.audit_log'))).rejects.toThrow(/permission denied/);
  });
  it('platform_admins is invisible, and only the helper answers about yourself', async () => {
    await db.query('insert into public.platform_admins (user_id) values ($1)', [B]);
    try {
      await expect(as(A, (q) => q('select * from public.platform_admins'))).rejects.toThrow(/permission denied/);
      await expect(as(A, (q) => q('insert into public.platform_admins (user_id) values ($1)', [A]))).rejects.toThrow(/permission denied/);
      expect((await as(A, (q) => q('select public.am_i_platform_admin() as v'))).rows[0].v).toBe(false);
      expect((await as(B, (q) => q('select public.am_i_platform_admin() as v'))).rows[0].v).toBe(true);
    } finally { await db.query('delete from public.platform_admins where user_id = $1', [B]); }
  });
  it('being Super Admin does NOT bypass tenant RLS', async () => {
    await db.query('insert into public.platform_admins (user_id) values ($1)', [B]);
    try {
      expect((await as(B, (q) => q('select 1 from public.projects where organization_id = $1', [orgA]))).rows.length).toBe(0);
    } finally { await db.query('delete from public.platform_admins where user_id = $1', [B]); }
  });
  it('anonymous users can read nothing', async () => {
    for (const t of ['organizations', 'memberships', 'brands', 'projects', 'profiles', 'audit_log', 'usage_events', 'platform_admins']) {
      await expect(as(null, (q) => q(`select 1 from public.${t}`))).rejects.toThrow(/permission denied/);
    }
  });
  it('suspending an organization locks its members out', async () => {
    await db.query(`update public.organizations set status = 'suspended' where id = $1`, [orgA]);
    try {
      expect((await as(A, (q) => q('select 1 from public.projects where organization_id = $1', [orgA]))).rows.length).toBe(0);
      expect((await as(A, (q) => q('select 1 from public.organizations where id = $1', [orgA]))).rows.length).toBe(0);
    } finally { await db.query(`update public.organizations set status = 'active' where id = $1`, [orgA]); }
  });
  it('users only see their own profile', async () => {
    expect((await as(A, (q) => q('select id from public.profiles'))).rows).toEqual([{ id: A }]);
  });
});
